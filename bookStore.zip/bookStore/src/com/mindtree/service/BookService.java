package com.mindtree.service;

import java.util.List;

import com.mindtree.entity.Book;

public interface BookService 
{
	public List<Book> addBook(Book book,List<Book> booklist);
	
	public void displayall(List<Book> booklist);
	
	public List<Book> purchase(String book,List<Book> booklist);
	
	public void displayBook(String bookname, List<Book> booklist);

	public void displayBookWithA(List<Book> booklist);
	
	
}
