package com.mindtree.serviceImpl;
import java.util.List;
import com.mindtree.entity.Book;
import com.mindtree.service.BookService;

public class BookServiceImpl implements BookService
{

	@Override
	public List<Book> addBook(Book book, List<Book> booklist) 
	{
		booklist.add(book);
		
		return booklist;
	}

	
	@Override
	public void displayall(List<Book> booklist) 
	{	
		for (Book book : booklist) 
		{
			System.out.println(book.toString());
		}
	}
	
	
	@Override
	public List<Book> purchase(String book, List<Book> booklist) 
	{
		for (Book book2 : booklist) 
		{
			if(book2.getName().equals(book))
			{
				System.out.println(book2.toString());
				
				book2.setQuantity(book2.getQuantity()-1);
			}
		}
	
		return booklist;
	}
	
	
	@Override
	public void displayBook(String bookname, List<Book> booklist) 
	{
		
		for (Book book2 : booklist) 
		{
			if(book2.getName().equals(bookname) && book2.getQuantity() != 0)
			{
				System.out.println(book2.toString());
			}
		}	
		
	}


	@Override
	public void displayBookWithA(List<Book> booklist) 
	{
		for (Book book : booklist) 
		{
			if(book.getName().charAt(0) == 'a')
			{
				System.out.println(book.toString());
			}
			
		}

		
	}
	
}

