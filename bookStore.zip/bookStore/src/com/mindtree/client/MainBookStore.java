package com.mindtree.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mindtree.entity.Book;
import com.mindtree.service.BookService;
import com.mindtree.serviceImpl.BookServiceImpl;

public class MainBookStore {
	static Scanner sc = new Scanner(System.in);
	public static void main(String args[]) 
	{
		List<Book> booklist = new ArrayList<Book>();
		
		BookService service = new BookServiceImpl();
		
		boolean flag = true;
		do {
			System.out.println("1.add book");
			System.out.println("2.display book by name");
			System.out.println("3.purchase book");

			int switchInteger = 0;
			boolean done = true;
			while (done) 
			{
				try 
				{
					System.out.println("enter a choice");
					switchInteger = sc.nextInt();
					sc.nextLine();
					done = false;
				}
				catch (Exception e) 
				{
					String str = sc.nextLine();
					System.out.println("enter a valid number");
				}
			}

			switch (switchInteger) 
			{
			case 1:

				System.out.println("enter book id");
				int id = sc.nextInt();
				sc.nextLine();

				System.out.println("enter book name");
				String name = sc.nextLine();

				System.out.println("enter book Author");
				String author = sc.nextLine();

				System.out.println("enter book price");
				int price = sc.nextInt();
				sc.nextLine();

				System.out.println("enter book quantity");
				int quantity = sc.nextInt();
				sc.nextLine();

				Book b = new Book(id, name, author, price, quantity);

				booklist = service.addBook(b, booklist);

				try {
					FileWriter myWriter = new FileWriter("D:\\FileHandling\\Filef1.txt");
					myWriter.write(booklist.toString());
					System.out.println();
					myWriter.close();
					System.out.println("sucessfully wrote the file");
				} catch (IOException e) {
					System.out.println("an error occured");
					e.printStackTrace();
				}

				break;
			case 2:
				System.out.println("enter book name to show");
				String bookname = sc.nextLine();
				sc.nextLine();
				service.displayBook(bookname, booklist);

				System.out.println("book name start with 'A' ");
				service.displayBookWithA(booklist);

				break;
			case 3:
				System.out.println("enter book name to purchase:");
				String bookpurchase = sc.nextLine();
				service.displayall(service.purchase(bookpurchase, booklist));

				break;
			case 4:
				flag = false;
				break;
			default:
				flag = false;
				break;
			}
		} while (flag);

	}
}
